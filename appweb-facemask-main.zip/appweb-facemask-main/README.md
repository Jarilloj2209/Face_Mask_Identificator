# appweb-facemask
Aplicación web para detectar si una persona usa o no cubrebocas 
